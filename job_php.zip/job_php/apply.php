<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $education = $_POST["education"];
    $workexp = $_POST["workexp"];
    $info = $_POST["info"];

    // Read the resume file content
    $resume = $_FILES["resume"]["tmp_name"];
    $resumeContent = file_get_contents($resume);

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "jbportal";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO apply (name, email, phone, address, education, workexp, resume, info) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $name, $email, $phone, $address, $education, $workexp, $resumeContent, $info);

    // Check for successful insertion
    if ($stmt->execute()) {
        echo "Application submitted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
