<?php
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "jbportal"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if (isset($_POST['full-name']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['mobile']) && isset($_POST['work-status']) && isset($_POST['current-city'])) {

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO login1 (name, email, password, mobile, status, loc) VALUES (?, ?, ?, ?, ?, ?)");
        
        if ($stmt === false) {
            die('Prepare() failed: ' . htmlspecialchars($conn->error));
        }

        // Set parameters and execute
        $fullName = $_POST['full-name'];
        $email = $_POST['email'];
        $hashedPassword = $_POST['password']; 
        $mobile = $_POST['mobile'];
        $workStatus = $_POST['work-status'];
        $currentCity = $_POST['current-city'];
        
        // Bind parameters
        $bind = $stmt->bind_param("ssssss", $fullName, $email, $hashedPassword, $mobile, $workStatus, $currentCity);
        
        if ($bind === false) {
            die('bind_param() failed: ' . htmlspecialchars($stmt->error));
        }

        // Execute statement
        $exec = $stmt->execute();
        
        if ($exec === false) {
            die('execute() failed: ' . htmlspecialchars($stmt->error));
        } else {
            echo "<script>alert('registered succesfully');</script>";
        }

        $stmt->close();
    } else {
        echo "All fields are required.";
    }
} else {
    echo "Invalid request method.";
}

$conn->close();
?>
