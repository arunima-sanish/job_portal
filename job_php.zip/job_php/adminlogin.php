<?php
session_start(); // Start session to store login info

include 'db_connect.php'; // Include your database connection file (make sure it's correct)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to fetch the admin's credentials from the database
    $query = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username); // Bind the username to the query
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verify the password using password_verify if stored hashed
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_username'] = $row['username']; // Store username in session

            // Redirect to admin dashboard if login is successful
            header("Location: admin_dashboard.php");
            exit(); // Make sure the script stops executing after the redirect
        } else {
            $error = "Invalid password!"; // Incorrect password
        }
    } else {
        $error = "Admin not found!"; // Admin username not found
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        /* Reset some default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('background-image.jpg'); /* Optional: Add a background image */
            background-size: cover;
        }

        /* Container for login form */
        .login-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 300px;
            text-align: center;
            box-sizing: border-box;
            transition: transform 0.3s ease-in-out;
        }

        .login-container:hover {
            transform: translateY(-10px); /* Optional hover effect */
        }

        /* Heading styling */
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #4CAF50; /* Green color for heading */
        }

        /* Label styling */
        label {
            font-size: 16px;
            display: block;
            margin-bottom: 5px;
            text-align: left;
            font-weight: bold;
        }

        /* Input fields */
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #4CAF50; /* Green border on focus */
        }

        /* Button styling */
        button[type="submit"] {
            background-color: #4CAF50; /* Green background */
            color: #fff;
            padding: 12px;
            width: 100%;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #45a049; /* Darker green when hovering */
        }

        /* Error message styling */
        .error {
            color: red;
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        <form method="POST">
            <label>Username:</label>
            <input type="text" name="username" required>
            
            <label>Password:</label>
            <input type="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>
        
        <?php 
        if (isset($error)) { 
            echo "<p class='error'>$error</p>"; // Display error message if login fails
        } 
        ?>
    </div>
</body>
</html>
