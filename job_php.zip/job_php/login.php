<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jbportal";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['email']) && !empty($_POST['password'])) {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        $stmt = $conn->prepare("SELECT name, email, password FROM login1 WHERE email = ?");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                // Check password
                if ($password === $row['password']) { // Replace with `password_verify($password, $row['password'])` if hashed
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['email'] = $row['email'];

                    // Clear output before redirection
                    ob_clean();
                    header("Location: http://localhost:8080/job_portal/home.html");
                    exit();
                } else {
                    echo "<script>alert('Invalid email or password'); window.location.href='login.html';</script>";
                }
            } else {
                echo "<script>alert('Invalid email or password'); window.location.href='login.html';</script>";
            }
            $stmt->close();
        }
    } else {
        echo "<script>alert('Email and password are required'); window.location.href='login.html';</script>";
    }
}

$conn->close();
?>
